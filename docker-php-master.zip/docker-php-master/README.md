# docker-php

Repositório para build automatico de PHP (FPM exclusivamente)

Repository for automated build of PHP (FPM exclusively)
